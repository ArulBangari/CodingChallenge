from data_analyzer import ShoppingDataAnalyzer
import logging
import pandas as pd

pd.set_option('display.float_format', '{:,.2f}'.format)

logging.basicConfig(
    filename="log.txt",
    level=logging.INFO,
    filemode="a",
    format="%(asctime)s [%(threadName)s] %(message)s"
)

def main():
    csv_location = "./CSVs/customer_shopping_data.csv"
    sda = ShoppingDataAnalyzer(csv_location)
    if sda.check_if_empty():
        print("Warning dataframe is empty!")
        logging.info("Warning dataframe is empty!")
        return
    
    gender_counts = sda.count_population_by_gender()
    print("2. Population grouped by gender:")
    print(gender_counts)
    print("\n")
    logging.info("2. Population grouped by gender")
    logging.info("Population grouped by gender:\n")
    logging.info(gender_counts.to_string())
    logging.info("\n")

    total_sales_by_gender = sda.total_sales_by_gender()
    print("3. Total sales by gender:")
    print(total_sales_by_gender)
    print("\n")    
    logging.info("3.Total sales by gender:\n")
    logging.info(total_sales_by_gender.to_string())
    logging.info("\n")


    most_used_payment, most_used_payment_freq =  sda.most_used_payment_method()
    print(f"4. Most used payment method: {most_used_payment} with {most_used_payment_freq} uses.")
    print("\n")
    logging.info(f"4.Most used payment method: {most_used_payment} with {most_used_payment_freq} uses.")
    logging.info("\n")

    date_with_most_sales, max_sales_count = sda.day_with_most_sales()
    print(f"5. Day with most sales: {date_with_most_sales} with ${max_sales_count} in sales.")
    logging.info("5.\n")
    logging.info(f"Day with most sales: {date_with_most_sales} with ${max_sales_count} in sales.")

main()